gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDGrassBGObjects1= [];
gdjs.Untitled_32sceneCode.GDGrassBGObjects2= [];
gdjs.Untitled_32sceneCode.GDroadObjects1= [];
gdjs.Untitled_32sceneCode.GDroadObjects2= [];
gdjs.Untitled_32sceneCode.GDcontrollerObjects1= [];
gdjs.Untitled_32sceneCode.GDcontrollerObjects2= [];
gdjs.Untitled_32sceneCode.GDbuilding1Objects1= [];
gdjs.Untitled_32sceneCode.GDbuilding1Objects2= [];
gdjs.Untitled_32sceneCode.GDbuilding2Objects1= [];
gdjs.Untitled_32sceneCode.GDbuilding2Objects2= [];
gdjs.Untitled_32sceneCode.GDbuilding3Objects1= [];
gdjs.Untitled_32sceneCode.GDbuilding3Objects2= [];

gdjs.Untitled_32sceneCode.conditionTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition1IsTrue_0 = {val:false};


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Untitled_32sceneCode.GDGrassBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("building1"), gdjs.Untitled_32sceneCode.GDbuilding1Objects1);
gdjs.copyArray(runtimeScene.getObjects("building2"), gdjs.Untitled_32sceneCode.GDbuilding2Objects1);
gdjs.copyArray(runtimeScene.getObjects("road"), gdjs.Untitled_32sceneCode.GDroadObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGrassBGObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGrassBGObjects1[i].addForce(0, 200, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDroadObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDroadObjects1[i].addForce(0, 200, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding1Objects1[i].addForce(0, 200, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding2Objects1[i].addForce(0, 200, 0);
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Untitled_32sceneCode.GDGrassBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("building1"), gdjs.Untitled_32sceneCode.GDbuilding1Objects1);
gdjs.copyArray(runtimeScene.getObjects("building2"), gdjs.Untitled_32sceneCode.GDbuilding2Objects1);
gdjs.copyArray(runtimeScene.getObjects("road"), gdjs.Untitled_32sceneCode.GDroadObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDroadObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDroadObjects1[i].addForce(200, 0, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGrassBGObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGrassBGObjects1[i].addForce(200, 0, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding1Objects1[i].addForce(200, 0, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding2Objects1[i].addForce(200, 0, 0);
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Untitled_32sceneCode.GDGrassBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("building1"), gdjs.Untitled_32sceneCode.GDbuilding1Objects1);
gdjs.copyArray(runtimeScene.getObjects("building2"), gdjs.Untitled_32sceneCode.GDbuilding2Objects1);
gdjs.copyArray(runtimeScene.getObjects("road"), gdjs.Untitled_32sceneCode.GDroadObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGrassBGObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGrassBGObjects1[i].addForce(0, -(200), 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDroadObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDroadObjects1[i].addForce(0, -(200), 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding1Objects1[i].addForce(0, -(200), 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding2Objects1[i].addForce(0, -(200), 0);
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Untitled_32sceneCode.GDGrassBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("building1"), gdjs.Untitled_32sceneCode.GDbuilding1Objects1);
gdjs.copyArray(runtimeScene.getObjects("building2"), gdjs.Untitled_32sceneCode.GDbuilding2Objects1);
gdjs.copyArray(runtimeScene.getObjects("road"), gdjs.Untitled_32sceneCode.GDroadObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDroadObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDroadObjects1[i].addForce(-(200), 0, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding2Objects1[i].addForce(-(200), 0, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGrassBGObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGrassBGObjects1[i].addForce(-(200), 0, 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbuilding1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbuilding1Objects1[i].addForce(-(200), 0, 0);
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDGrassBGObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGrassBGObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDroadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDroadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcontrollerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcontrollerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbuilding1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDbuilding1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDbuilding2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDbuilding2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDbuilding3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDbuilding3Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
